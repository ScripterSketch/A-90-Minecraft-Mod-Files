import {
  world,
  system,
  CommandPermissionLevel,
  CustomCommandParamType,
  CustomCommandStatus,
} from "@minecraft/server";

const ROLL_INTERVAL_TICKS = 200;
const ROLL_CHANCE = 0.10;
const IDLE_TICKS = 20;
const WARNING_TOTAL_TICKS = 41; // 2.05s; matches the 2.014s spawn sound at 20 TPS.
const JUMPSCARE_TICKS = 62;
const MOVE_DISTANCE = 0.025;
const LOOK_DEGREES = 2.0;

const encounters = new Map();
let loopsStarted = false;

function setOverlay(player, state) {
  try { player.onScreenDisplay.setActionBar(state); }
  catch (e) { console.warn(`[A-90] HUD state error: ${e}`); }
}
function clearOverlay(player) {
  try { player.onScreenDisplay.setActionBar(""); } catch {}
}
function getSnapshot(player) {
  const p = player.location, r = player.getRotation();
  return { x:p.x, y:p.y, z:p.z, pitch:r.x, yaw:r.y };
}
function angleDelta(a,b) { const d=Math.abs(a-b)%360; return d>180?360-d:d; }
function moved(player,start) {
  const n=getSnapshot(player), dx=n.x-start.x, dy=n.y-start.y, dz=n.z-start.z;
  return Math.sqrt(dx*dx+dy*dy+dz*dz)>MOVE_DISTANCE ||
    angleDelta(n.yaw,start.yaw)>LOOK_DEGREES || Math.abs(n.pitch-start.pitch)>LOOK_DEGREES;
}
function beginEncounter(player) {
  if (!player || encounters.has(player.id)) return false;
  encounters.set(player.id,{phase:'idle',start:getSnapshot(player),ticks:0});
  setOverlay(player,'A90_IDLE');
  try { player.playSound('a90.spawn'); } catch(e) { console.warn(`[A-90] Spawn sound error: ${e}`); }
  return true;
}
function endEncounter(player) { encounters.delete(player.id); clearOverlay(player); }
function jumpscare(player) {
  const s=encounters.get(player.id); if(!s) return;
  s.phase='jump'; s.ticks=0; setOverlay(player,'A90_JUMP');
  try { player.playSound('a90.jumpscare'); } catch(e) { console.warn(`[A-90] Jumpscare sound error: ${e}`); }
  // DOORS-style threshold: below 9 hearts (18 HP), the hit is fatal.
  // At 9 hearts or more, the player is left at 1 heart.
  try {
    const h=player.getComponent('minecraft:health');
    if(h) h.setCurrentValue(h.currentValue < 18 ? 0 : 2);
  } catch(e) { console.warn(`[A-90] Health update error: ${e}`); }
}
function startWorldLoops() {
  if(loopsStarted) return; loopsStarted=true;
  console.warn('[A-90] World loaded; encounter loops started.');
  system.runInterval(()=>{
    const players=world.getAllPlayers();
    for(const player of players) {
      const s=encounters.get(player.id); if(!s) continue;
      s.ticks++;
      if(s.phase==='jump') {
        if(s.ticks>=JUMPSCARE_TICKS) endEncounter(player);
        continue;
      }
      // End the warning exactly when the spawn sound has finished. Check this
      // before movement so movement on/after the end tick is safe.
      if(s.ticks>=WARNING_TOTAL_TICKS) { endEncounter(player); continue; }
      if((s.phase==='idle'||s.phase==='stop') && moved(player,s.start)) { jumpscare(player); continue; }
      if(s.phase==='idle' && s.ticks>=IDLE_TICKS) { s.phase='stop'; setOverlay(player,'A90_STOP'); }
    }
    const online=new Set(players.map(p=>p.id));
    for(const id of encounters.keys()) if(!online.has(id)) encounters.delete(id);
  },1);
  system.runInterval(()=>{
    for(const player of world.getAllPlayers()) if(!encounters.has(player.id) && Math.random()<ROLL_CHANCE) beginEncounter(player);
  },ROLL_INTERVAL_TICKS);
}
world.afterEvents.worldLoad.subscribe(()=>startWorldLoops());

// PlayerSelector lets Bedrock resolve @s, @a, @p, and @r into real Player objects.
system.beforeEvents.startup.subscribe(({customCommandRegistry})=>{
  customCommandRegistry.registerCommand({
    name:'a90:a-90',
    description:'Trigger an A-90 encounter for selected players.',
    permissionLevel:CommandPermissionLevel.GameDirectors,
    cheatsRequired:true,
    mandatoryParameters:[{name:'targets',type:CustomCommandParamType.PlayerSelector}]
  },(origin,targets)=>{
    const selected=Array.isArray(targets)?targets:[];
    if(selected.length===0) return {status:CustomCommandStatus.Failure,message:'A-90: no players matched. Try /a90:a-90 @s or /a90:a-90 @a.'};
    system.run(()=>{
      let triggered=0;
      for(const player of selected) if(beginEncounter(player)) triggered++;
      if(triggered===0 && origin.sourceEntity?.typeId==='minecraft:player') {
        try { origin.sourceEntity.sendMessage('§cA-90: those players already have an active encounter.'); } catch {}
      }
    });
    return {status:CustomCommandStatus.Success,message:`A-90: triggering for ${selected.length} selected player(s).`};
  });
});
console.warn('[A-90] Script loaded; waiting for world load.');
